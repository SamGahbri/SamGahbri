﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LicenceInfo.API.Models
{
    public class LicenceDto
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public int NumberOfTypeOfLicence
        {
            get
            {
                return TypeOfLicence.Count; 
            }
        }

        public ICollection<TypeOfLicenceDto> TypeOfLicence { get; set; }
          = new List<TypeOfLicenceDto>();


    }
}
