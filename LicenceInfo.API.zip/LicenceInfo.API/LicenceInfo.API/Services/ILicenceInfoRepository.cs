﻿using LicenceInfo.API.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LicenceInfo.API.Services
{
    public interface ILicenceInfoRepository
    {
        IEnumerable<Licence> GetLicences();

        Licence GetLicence(int licenceId, bool includeTypeOfLicence);

        IEnumerable<TypeOfLicence> GetTypeOfLicenceForLicence(int licenceId);

        TypeOfLicence GetTypeOfLicenceForLicence(int licenceId, int typeOfLicenceId);

        bool LicenceExists(int licenceId);
        
        bool LicenceExists(object licenceId);

        void AddTypeOfLicenceForLicence(int licenceId, TypeOfLicence typeOfLicence);

        //void UpdateTypeOfLicenceForLicence(int licenceId, TypeOfLicence typeOfLicence);

        //void DeleteTypeOfLicence(TypeOfLicence typeOfLicence);

        bool Save();
    }
}
