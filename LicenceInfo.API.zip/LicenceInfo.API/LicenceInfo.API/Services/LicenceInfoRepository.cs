﻿using LicenceInfo.API.Contexts;
using LicenceInfo.API.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LicenceInfo.API.Services
{
    public class LicenceInfoRepository : ILicenceInfoRepository
    {

        private LicenceInfoContext _context;

        public LicenceInfoRepository(LicenceInfoContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public void AddTypeOfLicenceForLicence(int licenceId, TypeOfLicence typeOfLicence)
        {
            var licence = GetLicence(licenceId, false);
            licence.TypeOfLicence.Add(typeOfLicence);
        }

        public Licence GetLicence(int licenceId, bool includeTypeOfLicence)
        {
            //throw new NotImplementedException();
            if (includeTypeOfLicence)
            {
                return _context.Licences.Include(c => c.TypeOfLicence)
                    .Where(c => c.Id == licenceId).FirstOrDefault();
            }

            return _context.Licences
                .Where(c => c.Id == licenceId).FirstOrDefault();
        }

        public IEnumerable<Licence> GetLicences()
        {
            //throw new NotImplementedException();
            return _context.Licences.OrderBy(c => c.Name).ToList();
        }

        public IEnumerable<TypeOfLicence> GetTypeOfLicenceForLicence(int licenceId)
        {
            //throw new NotImplementedException();
            return _context.TypeOfLicences
                .Where(p => p.LicenceId == licenceId).ToList();
        }

        public TypeOfLicence GetTypeOfLicenceForLicence(int licenceId, int typeOfLicenceId)
        {
            //throw new NotImplementedException();
            return _context.TypeOfLicences
                .Where(p => p.LicenceId == licenceId && p.Id == typeOfLicenceId).FirstOrDefault();
        }

        public bool LicenceExists(int licenceId)
        {
            return _context.Licences.Any(c => c.Id == licenceId);
        }

        public bool LicenceExists(object licenceId)
        {
            throw new NotImplementedException();
        }

        public bool Save()
        {
            return (_context.SaveChanges() >= 0); 
        }
    }
}
