﻿using LicenceInfo.API.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LicenceInfo.API.Contexts
{
    public class LicenceInfoContext : DbContext
    {
        public DbSet<Licence> Licences { get; set;  }
        public DbSet<TypeOfLicence> TypeOfLicences { get; set;  }

        public LicenceInfoContext(DbContextOptions<LicenceInfoContext> options)
           : base(options)
        {
           // Database.EnsureCreated();
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Licence>()
                .HasData(
                new Licence()
                {
                    Id = 1,
                    Name = "MMX A",
                    Description = "Case Management Web Application."
                },
                new Licence()
                {
                    Id = 2,
                    Name = "MMX B",
                    Description = "Case Management Web Application."
                },
                new Licence()
                {
                    Id = 3,
                    Name = "Service Chain A",
                    Description = "Case Management Web Application."
                },
                new Licence()
                {
                    Id = 4,
                    Name = "Service Chain B",
                    Description = "Case Management Web Application."
                });

            modelBuilder.Entity<Licence>()
                .HasData(
                new TypeOfLicence()
                {
                    Id = 5,
                    Name = "Full20",
                    Description = "This is a Full licence."
                },
                new TypeOfLicence()
                {
                    Id = 6,
                    Name = "Lite22",
                    Description = "This is a Lite licence."
                }
                );
               
            base.OnModelCreating(modelBuilder);
        }
        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlServer("ConnectionString");
        //    base.OnConfiguring(optionsBuilder);
        //}
    }
}
