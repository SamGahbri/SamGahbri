﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LicenceInfo.API.Profiles
{
    public class LicenceProfile : Profile
    {
        public LicenceProfile()
        {
            CreateMap<Entities.Licence, Models.LicenceWithoutTypeOfLicenceDto>();
            CreateMap<Entities.Licence, Models.LicenceDto>();
        }

    }
}
