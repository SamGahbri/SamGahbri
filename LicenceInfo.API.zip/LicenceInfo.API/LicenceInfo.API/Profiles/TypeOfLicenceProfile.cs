﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LicenceInfo.API.Profiles
{
    public class TypeOfLicenceProfile : Profile
    {
        public TypeOfLicenceProfile()
        {
            CreateMap<Entities.TypeOfLicence, Models.TypeOfLicenceDto>();
            CreateMap<Models.TypeOfLicenceForCreationDto, Entities.TypeOfLicence>();
        } 
    }
}
