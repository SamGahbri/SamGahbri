﻿using AutoMapper;
using LicenceInfo.API.Models;
using LicenceInfo.API.Services;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LicenceInfo.API.Controllers
{
    [ApiController]
    [Route("api/cities/{cityId}/pointsofinterest")]
    public class TypeOfLicenceController : ControllerBase
    {
        private readonly ILogger<TypeOfLicenceController> _logger;
        private readonly IMailService _mailService;
        private readonly ILicenceInfoRepository _licenceInfoRepository;
        private readonly IMapper _mapper;
        private int licenceId;

        public TypeOfLicenceController(ILogger<TypeOfLicenceController> logger, IMailService mailService, ILicenceInfoRepository licenceInfoRepository, IMapper mapper)
        {
              _logger = logger ?? 
                throw new ArgumentNullException(nameof(logger));
              _mailService = mailService ?? 
                throw new ArgumentNullException(nameof(mailService));
              _licenceInfoRepository = licenceInfoRepository ??
              throw new ArgumentNullException(nameof(licenceInfoRepository));
            _mapper = mapper ??
              throw new ArgumentNullException(nameof(mapper));
        }


        [HttpGet]
        public IActionResult GetTypeOfLicence(int licenceId)
        {
            try
            {
                //throw new Exception("Exception example");
                if (!_licenceInfoRepository.LicenceExists(licenceId))
                {
                    _logger.LogInformation($"Licence with id {licenceId} wasn't found when" + $"accessing type of licence.");
                    return NotFound();
                }


                var typeOfLicenceForLicence = _licenceInfoRepository.GetTypeOfLicenceForLicence(licenceId);

                //var typeOfLicenceForLicenceResults = new List<TypeOfLicenceDto>();
                //foreach (var tol in typeOfLicenceForLicence)
                //{
                //    typeOfLicenceForLicenceResults.Add(new TypeOfLicenceDto()
                //    {
                //        Id = tol.Id,
                //        Name = tol.Name,
                //        Description = tol.Description
                //    });
                //}

                return Ok(_mapper.Map<IEnumerable<TypeOfLicenceDto>>(typeOfLicenceForLicence));
                //var licence = LicenceDataStore.Current.Licences
                //    .FirstOrDefault(c => c.Id == LicenceId);

                //if (licence == null)
                //{
                //    _logger.LogInformation($"Licence with id {licenceId} wasn't found when accessing points of interest");
                //    return NotFound();
                //}

                //return Ok(licence.TypeOfLicence);
            }
            catch (Exception ex)
            {
                _logger.LogCritical($"Exception while getting points of interest for licence with id {licenceId}.", ex);
                return StatusCode(500, "A problem happend while handling your request.");
            }

        }

        [HttpGet("{id}", Name = "GetPointOfInterest")]
        public IActionResult GetTypeOfLicence(int licenceId, int id)
        {
            
            if (!_licenceInfoRepository.LicenceExists(licenceId))
            {
                return NotFound();
            }

            var typeOfLicence = _licenceInfoRepository.GetTypeOfLicenceForLicence(licenceId, id);

            if (typeOfLicence == null)
            {
                return NotFound();
            }

            //var typeOfLicenceResult = new TypeOfLicenceDto()
            //{
            //    Id = typeOfLicence.Id,
            //    Name = typeOfLicence.Name,
            //    Description = typeOfLicence.Description
            //};

            return Ok(_mapper.Map<TypeOfLicenceDto>(typeOfLicence));
            //var licence = LicenceDataStore.Current.Licences
            //    .FirstOrDefault(c => c.Id == LicenceId);

            //if (licence == null)
            //{
            //    return NotFound();
            //}

            ////find type of licence
            //var typeOfLicence = licence.TypeOfLicence
            //    .FirstOrDefault(c => c.Id == id);

            //if (typeOfLicence == null)
            //{
            //    return NotFound();
            //}

            //return Ok(typeOfLicence);
        }

        [HttpPost]
        public IActionResult CreateTypeOfLicence(int LicenceId,
            [FromBody]TypeOfLicenceForCreationDto typeOfLicence)
        {
            if (typeOfLicence.Description == typeOfLicence.Name)
            {
                ModelState.AddModelError(
                    "Description", "The provided Description should be diffrent from the name.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (!_licenceInfoRepository.LicenceExists(licenceId))
            {
                return NotFound();
            }
            //var licence = LicenceDataStore.Current.Licences.FirstOrDefault(c => c.Id == LicenceId);
            //if (licence == null)
            //{
            //    return NotFound();
            //}

            // This will be improved
            //var maxTypeOfLicenceId = LicenceDataStore.Current.Licences.SelectMany(
            //             c => c.TypeOfLicence).Max(p => p.Id);

            //var finalTypeOfLicence = new TypeOfLicenceDto()
            //{
            //    Id = ++maxTypeOfLicenceId,
            //    Name = typeOfLicence.Name,
            //    Description = typeOfLicence.Description
            //};
            var finalTypeOfLicence = _mapper.Map<Entities.TypeOfLicence>(typeOfLicence);

            _licenceInfoRepository.AddTypeOfLicenceForLicence(licenceId, finalTypeOfLicence);

            _licenceInfoRepository.Save();

            var createdTypeOfLicenceToReturn = _mapper.Map<Models.TypeOfLicenceDto>(finalTypeOfLicence);

            return CreatedAtRoute(
                "GetTypeOfLicence",
                new { LicenceId, id = createdTypeOfLicenceToReturn.Id },
               createdTypeOfLicenceToReturn);

        }

        [HttpPut ("{id}")]
        public IActionResult UpdateTypeOfLicence(int LicenceId, int id, [FromBody] TypeOfLicenceForUpdateDto typeOfLicence)
        {
            if (typeOfLicence.Description == typeOfLicence.Name)
            {
                ModelState.AddModelError(
                    "Description",
                    "The provided description should be different from the name.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var licence = LicenceDataStore.Current.Licences.FirstOrDefault(c => c.Id == LicenceId);
            if (licence == null)
            {
                return NotFound();
            }

            var typeOfLicenceFromStore = licence.TypeOfLicence
                .FirstOrDefault(c => c.Id == LicenceId);
            if (typeOfLicence ==null)
            {
                return NotFound();
            }

            typeOfLicenceFromStore.Name = typeOfLicence.Name;
            typeOfLicenceFromStore.Description = typeOfLicence.Description;

            return NoContent();
        }
        
        [HttpPatch ("{id}")]

        public IActionResult PartiallyUpdateTypeOfLicence(int licenceId, int id, [FromBody] JsonPatchDocument<TypeOfLicenceForUpdateDto> patchDoc)
        {
            var licence = LicenceDataStore.Current.Licences.FirstOrDefault(c => c.Id == licenceId);
            if (licence == null)
            {
                return NotFound();
            }

            var typeOfLicenceFromStore = licence.TypeOfLicence
                .FirstOrDefault(c => c.Id == id);
            if (typeOfLicenceFromStore == null)
            {
                return NotFound();
            }

            var typeOfLicenceToPatch =
                new TypeOfLicenceForUpdateDto()
                {
                    Name = typeOfLicenceFromStore.Name,
                    Description = typeOfLicenceFromStore.Description
                };

            patchDoc.ApplyTo(typeOfLicenceToPatch, ModelState);

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (typeOfLicenceToPatch.Description == typeOfLicenceToPatch.Name)
            {
                ModelState.AddModelError(
                    "Description",
                    "The provided description should be diffrent from the name.");
            }

            if (!TryValidateModel(typeOfLicenceToPatch))
            {
                return BadRequest(ModelState);
            }

            typeOfLicenceFromStore.Name = typeOfLicenceToPatch.Name;
            typeOfLicenceFromStore.Description = typeOfLicenceToPatch.Description;

            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteTypeOfLicence(int licenceId, int id)
        {
            var licence = LicenceDataStore.Current.Licences.FirstOrDefault(c => c.Id == licenceId);
            if (licence == null)
            {
                return NotFound();
            }

            var typeOfLicenceFromStore = licence.TypeOfLicence
                .FirstOrDefault(c => c.Id == id);
            if (typeOfLicenceFromStore == null)
            {
                return NotFound();
            }

            licence.TypeOfLicence.Remove(typeOfLicenceFromStore);

            _mailService.Send("Point of interest deleted.",
                    $"Point of interest {typeOfLicenceFromStore.Name} with id {typeOfLicenceFromStore.Id} was deleted.");

            return NoContent();
        }
        
    }
}
    //{
    //    public object TypeOfLicence { get; private set; }

    //    [HttpGet]

    //    public IActionResult GetTypeOfLicence(int cityId)
    //    {
    //        var licenceToReturn = LicenceDataStore.Current.Licences
    //            .FirstOrDefault(c => c.Id == cityId);

    //        if (licenceToReturn == null)
    //        {
    //            return NotFound();
    //        }

    //        return Ok(TypeOfLicence);

    //    }

    //    private IActionResult Ok(object TypeOfLicence)
    //    {
    //        throw new NotImplementedException();
    //    }
//    }

