﻿using AutoMapper;
using LicenceInfo.API.Models;
using LicenceInfo.API.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LicenceInfo.API.Controllers
{
    [ApiController] /*API attribute controller - imprves the devlopment experience when building API's*/
    [Route("api/cities")]
    public class LicenceController : ControllerBase
    {
        private readonly ILicenceInfoRepository _licenceInfoRepository;
        private readonly IMapper _mapper;
        

        public LicenceController(ILicenceInfoRepository licenceInfoRepository, IMapper mapper)
        {
            _licenceInfoRepository = licenceInfoRepository ??
                throw new ArgumentNullException(nameof(licenceInfoRepository));
            _mapper = mapper ??
                throw new ArgumentNullException(nameof(mapper));
        }

        [HttpGet]
        public IActionResult GetLicences() /*returns a JSON result object*/
        {

            var licenceEntities = _licenceInfoRepository.GetLicences();

            //var results = new List<LicenceWithoutTypeOfLicenceDto>();

            //foreach (var licenceEntity in licenceEntities)
            //{
            //    results.Add(new LicenceWithoutTypeOfLicenceDto
            //    {

            //        Id = licenceEntity.Id,
            //        Description = licenceEntity.Description,
            //        Name = licenceEntity.Name
            //    });
            //}
            //return Ok(LicenceDataStore.Current.Licences);
            //return new JsonResult(
            //    new List<object>()
            //    {
            //        new {id = 1, Name = "Service Chain A"},
            //        new {id = 2, Name = "Service Chain B"},
            //        new {id = 2, Name = "MMX A"},
            //        new {id = 2, Name = "MMX B"}
            //    });
            return Ok(_mapper.Map<IEnumerable<LicenceWithoutTypeOfLicenceDto>>(licenceEntities));
        }

        [HttpGet("{id}")] /*Get ID of the licence*/
        public IActionResult GetLicence(int id, bool includeTypeOfLicence = false) /*New action added*/
        {
            var licence = _licenceInfoRepository.GetLicence(id, includeTypeOfLicence);

            if (licence == null)
            {
                return NotFound();
            }

            if (includeTypeOfLicence)
            {
                //var licenceResult = _mapper.Map<LicenceDto>(licence);
            
            
                //var licenceResult = new LicenceDto()
                //{
                //    Id = licence.Id,
                //    Name = licence.Name,
                //    Description = licence.Description
                //};

                //foreach (var tol in licence.TypeOfLicence)
                //{
                //    licenceResult.TypeOfLicence.Add(new TypeOfLicenceDto()
                //    {
                //        Id = tol.Id,
                //        Name = tol.Name,
                //        Description = tol.Description
                //    });
                //}

                return Ok(_mapper.Map<LicenceDto>(licence));
            }

            //var licenceWithoutTypeOfLicenceResult = new LicenceWithoutTypeOfLicenceDto()
            //{
            //    Id = licence.Id,
            //    Description = licence.Description,
            //    Name = licence.Name
            //};

            return Ok(_mapper.Map<LicenceWithoutTypeOfLicenceDto>(licence));
            ////Find Licence 
            //var licenceToReturn = LicenceDataStore.Current.Licences
            //    .FirstOrDefault(c => c.Id == id);

                //if (licenceToReturn == null) 
                //{
                //    return NotFound();
                //}

                //return Ok(licenceToReturn);
                ////return new JsonResult(
                ////    LicenceDataStore.Current.Licences.FirstOrDefault(c => c.Id == id)); /*Look for a licence with the id of id. We then return the json result of that*/
        }
    }
}
