﻿using LicenceInfo.API.Contexts;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LicenceInfo.API.Controllers
{
    [ApiController]
    [Route("api/testdatabase")]
    public class DummyController : ControllerBase
    {
        private readonly LicenceInfoContext _ltx;

        public DummyController(LicenceInfoContext ltx)
        {
            _ltx = ltx ?? throw new ArgumentNullException(nameof(ltx));
        }

        [HttpGet]
        public IActionResult TestDatabase()
        {
            return Ok();
        }


    }
}
