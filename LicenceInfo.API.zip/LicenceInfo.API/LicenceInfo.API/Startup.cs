﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using LicenceInfo.API.Contexts;
using LicenceInfo.API.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json.Serialization;

namespace LicenceInfo.API
{
    public class Startup
    {
        private readonly IConfiguration _configuration;


        public Startup(IConfiguration configuration)
        {
            _configuration = configuration ??
                throw new ArgumentException(nameof(configuration));
        }
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services) /*This is responsible for adding services to the container and to add services */
        {
            services.AddMvc()
                 .AddMvcOptions(o =>
                  {
                      o.OutputFormatters.Add(new XmlDataContractSerializerOutputFormatter()); //Thsi statment is used to output XML instead of Json in Postman. In the GetCities part.
                  });
            //.AddJsonOptions(o =>
            //{
            //    if (o.SerializerSettings.ContractResolver != null)
            //    {
            //        var castedResolver = o.SerializerSettings.ContractResolver
            //                               as DefaultContractResolver;
            //        castedResolver.NamingStrategy = null;
            //    }
            //});
#if DEBUG
            services.AddTransient<IMailService, LocalMailService>();
#else
            services.AddTransient<IMailService, CloudMailService>();
#endif

            var connectionString = _configuration["connectionStrings:licenceInfoDBConnectionString"];
            //var connectionString = _configuration["connectionStrings:LicenceInfoDBConnectionString"];
            services.AddDbContext<LicenceInfoContext>(o =>
            {
                o.UseSqlServer(connectionString);
            });

            services.AddScoped<ILicenceInfoRepository, LicenceInfoRepository>();
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env) /*I appication builder and a I host environment are provided by the container*/
        {
            if (env.IsDevelopment()) /*defining the environment which you want to execute*/
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler();/* Catches exception and logs then and then re executes. Stack trace wont be exposed */
            }

            app.UseStatusCodePages();

            app.UseMvc();

            //app.Run((context) =>
            //{
            //    //await context.Response.WriteAsync("Hello World!");
            //    throw new Exception("Example Exception");
            //});
        }
    }
}
