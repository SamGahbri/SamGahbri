﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace LicenceInfo.API.Migrations
{
    public partial class LicenceInfoDBAddToLDescription : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Description",
                table: "TypeOfLicences",
                maxLength: 200,
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Description",
                table: "TypeOfLicences");
        }
    }
}
