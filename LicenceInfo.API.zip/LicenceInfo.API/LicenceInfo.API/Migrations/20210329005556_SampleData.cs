﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace LicenceInfo.API.Migrations
{
    public partial class SampleData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Licences",
                columns: new[] { "Id", "Description", "Name" },
                values: new object[,]
                {
                    { 1, "Case Management Web Application.", "MMX A" },
                    { 2, "Case Management Web Application.", "MMX B" },
                    { 3, "Case Management Web Application.", "Service Chain A" },
                    { 4, "Case Management Web Application.", "Service Chain B" },
                    { 5, "This is a Full licence.", "Full20" },
                    { 6, "This is a Lite licence.", "Lite22" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Licences",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Licences",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Licences",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Licences",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Licences",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Licences",
                keyColumn: "Id",
                keyValue: 6);
        }
    }
}
