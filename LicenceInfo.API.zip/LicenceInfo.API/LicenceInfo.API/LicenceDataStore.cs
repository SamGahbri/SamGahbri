﻿using LicenceInfo.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LicenceInfo.API
{
    public class LicenceDataStore
    {
        public static LicenceDataStore Current { get; } = new LicenceDataStore(); //*Allows us to easily access the licence data store*//

        public List<LicenceDto> Licences { get; set; }

        public LicenceDataStore()
        {
            //init dummy data
            Licences = new List<LicenceDto>()
            {
                new LicenceDto()
                {
                    Id = 1,
                    Name = "MMX A",
                    Description = "Case Management Web Application",
                    TypeOfLicence = new List<TypeOfLicenceDto>()
                    {
                        new TypeOfLicenceDto()
                        {
                            Id = 2,
                            Name = "Full20",
                            Description = "This is a Full licence." },
                        new TypeOfLicenceDto()
                        {
                            Id = 3,
                            Name = "Full21",
                            Description = "This is a Full licence." },
                    }

                },
                new LicenceDto()
                {
                    Id = 2,
                    Name = "MMX B",
                    Description = "Case Management Web Application",
                    TypeOfLicence = new List<TypeOfLicenceDto>()
                    {
                        new TypeOfLicenceDto()
                        {
                            Id = 3,
                            Name = "Lite22",
                            Description = "This is a Lite licence." },
                        new TypeOfLicenceDto()
                        {
                            Id = 4,
                            Name = "Lite23",
                            Description = "This is a Lite licence." },
                    }

                },
                new LicenceDto()
                {
                    Id = 3,
                    Name = "Service Chain A",
                    Description = "Case Management Web Application",
                    TypeOfLicence = new List<TypeOfLicenceDto>()
                    {
                        new TypeOfLicenceDto()
                        {
                            Id = 4,
                            Name = "Full1",
                            Description = "This is a full licence." },
                        new TypeOfLicenceDto()
                        {
                            Id = 5,
                            Name = "Full2",
                            Description = "This is a full licence." },
                        }
                    
                },
                new LicenceDto()
                {
                    Id = 4,
                    Name = "Service Chain B",
                    Description = "Case Management Web Application",
                    TypeOfLicence = new List<TypeOfLicenceDto>()
                    {
                        new TypeOfLicenceDto()
                        {
                            Id = 5,
                            Name = "Lite1",
                            Description = "This is a Lite Licence." },
                        new TypeOfLicenceDto()
                        {
                            Id = 6,
                            Name = "Lite2",
                            Description = "This is a half lite licence. "}


                    }

                }
            };
        }
    }
}
